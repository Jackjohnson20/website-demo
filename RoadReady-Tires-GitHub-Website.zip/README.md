# RoadReady Tires Website

A simple, responsive static tire website designed to work with GitHub Pages.

## How to use

1. Create a new GitHub repository.
2. Upload `index.html`.
3. Open the repository's **Settings → Pages**.
4. Under the deployment/source option, select the branch containing `index.html` (usually `main`) and the root folder.
5. Save. GitHub will provide your website URL.

## Customize

Open `index.html` and search/replace:
- `RoadReady Tires` — your business name
- `(555) 123-4567` — your phone
- `hello@example.com` — your email
- `123 Main Street, Your City, ST 00000` — your address
- Prices and tire descriptions
- Image URLs if you want your own photos

No database, framework, or build process is required.
